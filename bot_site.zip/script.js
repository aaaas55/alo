
function runBot() {
  document.getElementById('status').innerText = "الحالة: البوت يعمل...";
  alert("تم تشغيل البوت (تجريبي)!");
}
